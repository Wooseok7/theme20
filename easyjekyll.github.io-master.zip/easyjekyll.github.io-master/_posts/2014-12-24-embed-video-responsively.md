---
layout: post
title: Embed YouTube video responsively test
tags: embed youtube responsive jekyll plugin
---
<iframe width="560" height="315" src="//www.youtube.com/embed/DKDVhCWsgP4" frameborder="0" allowfullscreen></iframe>

반응형으로 영상이 잘 삽입되는지 확인하는 글입니다. 창의 크기를 마음껏 늘였다가 줄여도 영상이 잘 보여야 합니다. 만약 영상의 일부분이 잘리면 실패입니다.
